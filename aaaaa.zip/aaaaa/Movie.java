package entity;

public class Movie {
	private int mId;
	private String mImg;
	private String mDir;
	private String mScr;
	private String mAct;
	private String mType;
	private String mCountry;
	private String mTime;
	private String mLanguage;
	private String mIntro;
	private String mName;
	public String getmLanguage() {
		return mLanguage;
	}
	public void setmLanguage(String mLanguage) {
		this.mLanguage = mLanguage;
	}
	public String getmIntro() {
		return mIntro;
	}
	public void setmIntro(String mIntro) {
		this.mIntro = mIntro;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	public String getmImg() {
		return mImg;
	}
	public void setmImg(String mImg) {
		this.mImg = mImg;
	}
	public String getmDir() {
		return mDir;
	}
	public void setmDir(String mDir) {
		this.mDir = mDir;
	}
	public String getmScr() {
		return mScr;
	}
	public void setmScr(String mScr) {
		this.mScr = mScr;
	}
	public String getmAct() {
		return mAct;
	}
	public void setmAct(String mAct) {
		this.mAct = mAct;
	}
	public String getmType() {
		return mType;
	}
	public void setmType(String mType) {
		this.mType = mType;
	}
	public String getmCountry() {
		return mCountry;
	}
	public void setmCountry(String mCountry) {
		this.mCountry = mCountry;
	}
	public String getmTime() {
		return mTime;
	}
	public void setmTime(String mTime) {
		this.mTime = mTime;
	}
	
}

