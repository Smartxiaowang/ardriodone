package util;

import model.Product;

import java.util.ArrayList;
import java.util.List;

public class StaticUtil {

    /**
     * 购物车商品信息
     */
    public static List<Product> cart;

}
