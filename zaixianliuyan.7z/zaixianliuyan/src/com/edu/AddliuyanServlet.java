package com.edu;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddliuyanServlet
 */
@WebServlet("/AddliuyanServlet")
public class AddliuyanServlet extends HttpServlet {

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddliuyanServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String neirong = request.getParameter("neirong");
		String title = request.getParameter("title");


		DBUtil db = new DBUtil();
		Connection conn = null;
		Statement stmt = null;//声明Statement类的对象，默认为Null,后面会赋值的，用来描述数据库查询的操作，至于这个名字不记得的，背下来，外国人起的名字。。必须这么写

		try {
			Date date = new Date();
			SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			System.out.println(dateFormat.format(date));

			conn = db.getConnection();//传入数据库的链接地址，账号信息，密码信息，获取数据库的链接类
			PreparedStatement preparedStatement = conn.prepareStatement("insert into liuyan(neirong,shijian,username,title) values (?,?,?,?)");//准备好插入数据库的语句
			preparedStatement.setString(1, neirong);//赋值mz的值给上面这行的第1个问号
			preparedStatement.setString(2, dateFormat.format(date));//赋值mm的值给上面这行的第2个问号
			preparedStatement.setString(3, username);//赋值mm的值给上面这行的第2个问号
			preparedStatement.setString(4, title);//赋值mm的值给上面这行的第2个问号
			preparedStatement.executeUpdate();//执行更新操作
			
			request.getRequestDispatcher("liuyansuccess.jsp").forward(request,response);
 		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
