package com.edu;

public class Main {
	public static void main(String[] args) {
		int a = 1;
		int b = 1;
		int c = 0;
		int d = a + b;
		try {
			int e = a/c;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("运行结束");
		
	}

}
