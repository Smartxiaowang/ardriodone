package com.edu;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")//定义servlet的访问路径
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mz = request.getParameter("mz");//获取denglu.jsp中名字的值
		String mm = request.getParameter("mm");//获取denglu.jsp中密码的值
		DBUtil db = new DBUtil();
		Connection conn = null;
		Statement stmt = null;//声明Statement类的对象，默认为Null,后面会赋值的，用来描述数据库查询的操作，至于这个名字不记得的，背下来，外国人起的名字。。必须这么写

		try {

			conn = db.getConnection();//传入数据库的链接地址，账号信息，密码信息，获取数据库的链接类
			stmt = conn.createStatement();//通过数据库链接对象创建数据库查询对象
			ResultSet rs = stmt.executeQuery("select * from user where username = '"+mz+"' and password='"+mm+"'");//传入查询数据库的sql语句

			boolean exist = false;//设置布尔变量，后面用来判断用户是否存在，假定用户不存在
			while (rs.next()) {//表示数据不止一行，需要用循环的方式打印出来
				exist = true;//进去while循环表示查到数据了，那么用户是存在的
			}
			if(exist) {//如果用户存在，说明登录成功了
				request.setAttribute("msg", "<script>alert('登录成功！')</script>");//弹窗显示登录成功，在登录的那个jsp文件中，通过${msg}来引用
				request.setAttribute("mz", mz);//把登录账号的值存到mz中，在biao.jsp通过${mz}来引入
				request.getSession().setAttribute("username", mz);
				request.setAttribute("mm", mm);//把登录账号的值存到mm中，在biao.jsp通过${mm}来引入
				request.getRequestDispatcher("addliuyan.jsp").forward(request, response);//跳转到biao.jsp
			}else {//说明登录失败了 
				request.setAttribute("msg", "<script>alert('账号密码错误！')</script>");//弹窗显示账号密码错误，在登录的那个jsp文件中，通过${msg}来引用
				request.getRequestDispatcher("denglu.jsp").forward(request, response);//跳转到登录页面,denglu.jsp
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//加载JDBC的驱动，上面的驱动类的名字不能写错
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
