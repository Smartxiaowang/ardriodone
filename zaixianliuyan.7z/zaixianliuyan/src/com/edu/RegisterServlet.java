package com.edu;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mz = request.getParameter("mz");//获取zhuce.jsp中名字的值
		String mm = request.getParameter("mm");//获取zhuce.jsp中密码的值
		DBUtil db = new DBUtil();
		Connection conn = null;
		Statement stmt = null;//声明Statement类的对象，默认为Null,后面会赋值的，用来描述数据库查询的操作，至于这个名字不记得的，背下来，外国人起的名字。。必须这么写
		 
			try {

				conn = db.getConnection();//传入数据库的链接地址，账号信息，密码信息，获取数据库的链接类
				stmt = conn.createStatement();//通过数据库链接对象创建数据库查询对象
				ResultSet rs = stmt.executeQuery("select * from user where username = '"+mz+"'");//传入查询数据库的sql语句
				boolean exist = false;//设置布尔变量，后面用来判断用户是否存在，假定用户不存在
				while (rs.next()) {//表示数据不止一行，需要用循环的方式打印出来
					exist = true;//进去while循环表示查到数据了，那么用户是存在的
				}
				if(!exist) {//用户不存在
					PreparedStatement preparedStatement = conn.prepareStatement("insert into user(username,password) values (?,?)");//准备好插入数据库的语句
					preparedStatement.setString(1, mz);//赋值mz的值给上面这行的第1个问号
					preparedStatement.setString(2, mm);//赋值mm的值给上面这行的第2个问号
					preparedStatement.executeUpdate();//执行更新操作
					preparedStatement.close();//关闭
					request.setAttribute("msg", "<script>alert('注册成功！')</script>");//弹窗显示注册成功，在登录的那个jsp文件中，通过${msg}来引用
					request.getRequestDispatcher("denglu.jsp").forward(request, response);//跳转到登录页面,denglu.jsp
				}else {
					request.setAttribute("msg", "<script>alert('账号已经存在，注册失败！')</script>");//弹窗显示账号密码已经存在，在注册的那个jsp文件中，通过${msg}来引用
					request.getRequestDispatcher("zhuce.jsp").forward(request, response);//跳转到注册页面,zhuce.jsp
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
