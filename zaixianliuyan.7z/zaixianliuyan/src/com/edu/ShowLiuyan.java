package com.edu;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "ShowLiuyan", value = "/ShowLiuyan")
public class ShowLiuyan extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {



        DBUtil db = new DBUtil();
        Connection conn = null;
        Statement stmt = null;//声明Statement类的对象，默认为Null,后面会赋值的，用来描述数据库查询的操作，至于这个名字不记得的，背下来，外国人起的名字。。必须这么写

        try {
            conn = db.getConnection();//传入数据库的链接地址，账号信息，密码信息，获取数据库的链接类


            stmt = conn.createStatement();//通过数据库链接对象创建数据库查询对象
            ResultSet rs = stmt.executeQuery("select * from liuyan");//传入查询数据库的sql语句
            List<Liuyan> liuyans = new ArrayList<Liuyan>();
            while (rs.next()) {
                int id = rs.getInt("id");
                String nr = rs.getString("neirong");
                String shijian = rs.getString("shijian");
                String user = rs.getString("username");
                String title = rs.getString("title");
                Liuyan liuyan = new Liuyan();
                liuyan.setId(id);
                liuyan.setNeirong(nr);
                liuyan.setUsername(user);
                // 解析字符串时间，转换成 Date 类型
                liuyan.setShijian(shijian);
                liuyan.setTitle(title);
                liuyans.add(liuyan);

            }
            request.setAttribute("liuyans", liuyans);
            request.getRequestDispatcher("liuyanlist.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
