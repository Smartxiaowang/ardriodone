package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
    private static final long serialVersionUID = 1L;
    static String jdbcDriver = "com.mysql.jdbc.Driver";//这个是固定的，表示"com.mysql.jdbc.Driver"这个字符串是固定的
    static String DB_URL = "jdbc:mysql://127.0.0.1:3306/test_0501?useSSL=false&serverTimezone=Asia/Shanghai&useUnicode=true&characterEncoding=utf-8&allowPublicKeyRetrieval=true";//47.101.198.61代表数据库的ip，如果数据库在本地，那么默认就为47.101.198.61或者127.0.0.1
    //3306代表数据库的端口号，默认为3306
    //test0519是链接的数据库的名字。

    static String USER = "root";//数据库的账号，默认为root
    static  String PASS = "123456";//数据库的密码
    public Connection getConnection() {
        Connection conn = null;//声明Connection类的对象，默认为Null,后面会赋值的，用来描述链接数据库的操作，至于这个名字不记得的，背下来，外国人起的名字。。必须这么写

        try{
            Class.forName(jdbcDriver);////加载JDBC的驱动，上面的驱动类的名字不能写错
            conn = DriverManager.getConnection(DB_URL,USER,PASS);//传入数据库的链接地址，账号信息，密码信息，获取数据库的链接类
        }catch (Exception e){

        }

        return  conn;
    }
}
